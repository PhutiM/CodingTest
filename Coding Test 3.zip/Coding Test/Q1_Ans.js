const fs = require('fs')
const Data = 'Question-1.js'

const dataBuffer = fs.readFileSync('Question-1.js')
const dataJson = dataBuffer.toString()
s