import React from 'react';
import { Text , View } from 'react-native';

class UserData extends Component{
    render(){
    const {textStyle, viewStyle} = styles;
    return (
    <View style={viewStyle}>
       <Text style={textStyle}> {this.Firstname}</Text>
       <Text style={textStyle}> {this.SecondName}</Text>
       <Text style={textStyle}> {this.Email}</Text>
       <Text style={textStyle}> {this.Age}</Text>
       <Text style={textStyle}> {this.CreatedDate}</Text>
    </View>
    );
};
}
export default UserData

//Add Styling   

const styles = {
    viewStyle:{
        backgroundColor: '#f8f8f8',
        justifyContent: 'center',
        alignItems: 'center',
        height: 100,
        paddingtop: 15,
        shadowColor: '#000',
        shadowOffset: {width:0, height:2 },
        shadowOpacity: 0.2,
        elevation: 2,
        position:'relative',
    },
    textStyle: {
        fontSize: 14,
    },
};